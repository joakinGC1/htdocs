

<th scope="row"><?= $fila["Producto"]?></th>
    <td><?= $fila["Cliente"]?></td>
    <td><?=$fila["cantidad"]?></td>
    <td><?=$fila["precio"]?></td>
    </tr>