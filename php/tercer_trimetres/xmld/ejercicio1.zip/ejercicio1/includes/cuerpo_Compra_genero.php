
<option value="<?= $fila["id_categoria"] ?>">
<?= $fila["nombre_generos"] ?>
</option>  