

<a href="#" class="dropdown-item">
<h6 class="fw-normal mb-0"><?= $fila["nombre"] ?></h6>
<small><?=  $fila["fecha"]  ?></small>
</a>
<hr class="dropdown-divider">