# CSS Vampire

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/JjXPdZq](https://codepen.io/alvaromontoro/pen/JjXPdZq).

