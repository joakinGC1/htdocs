<?php

require("./db_conect.php");
$query = "select * from compra";
$result = $con->query($query);
$fecha = array();
$totales = array();



if($result->num_rows > 0){
    while($fila = $result->fetch_assoc()){
       
        array_push($fecha,$fila["total"]);
        array_push($totales,$fila["fecha"]);
        
        
    }
}else{
    
}
?>





<script>
    var ctx1 = $("#worldwide-sales").get(0).getContext("2d");
    var myChart1 = new Chart(ctx1, {
        type: "bar",
        data: {
            labels: [<?php
                    for($i = 0; $i < count($fecha);$i++){
                        echo "'$fecha[$i]'". " ,";
                    }
                    echo '0';
                ?>
            ],
            datasets: [{
                    label: "PRODUCTOS",
                    data:[<?php
                        for($i = 0; $i < count($totales);$i++){
                            echo "'$totales[$i]'". " ,";
                        } 
                        echo '0';  
                    ?>];
                    backgroundColor: "rgba(235, 22, 22, .7)"
                }
            ]
            },
        options: {
            responsive: true
        }
    });

    
</script>