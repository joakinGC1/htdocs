<a href="#" class="dropdown-item">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle" src="<?= $fila["img"]?>" alt="" style="width: 40px; height: 40px;">
                                <div class="ms-2">
                                        <h6 class="fw-normal mb-0"><?= $fila["mensaje"] ?></h6>
                                        <small><?= $fila["fecha"]  ?></small>
                                    </div>
                                </div>
                            </a>

