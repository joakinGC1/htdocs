

<?php
    
    $con = mysqli_connect(
        '127.0.0.1:3307',
        'Javi',
        'simanadulto1J',
        'bd_utv'
    )or die(mysqli_error($con));

?>